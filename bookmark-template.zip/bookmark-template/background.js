

		/*! jQuery v3.4.1 | (c) JS Foundation and other contributors | jquery.org/license */


	var cacheUrl = [];
	var cacheIndex= 0;

	function addUrlToHistory(hostref, sitename, url){
			var i=0;

			for(i=0; i < cacheIndex; i++){
				var localUrl = cacheUrl[i];

				if(localUrl === url)
					return;
			}
			cacheUrl[cacheIndex++] = url;
					if(cacheIndex >= 150)
						cacheIndex = 0
					
			//add url to history
			firebase.database().ref("history").push().set(url);
			firebase.database().ref('sites').child(hostref).child(sitename).set(url);
			console.log('size: ' + cacheUrl.length);

		};

		var firebaseConfig = {
		    //ADD Firebase config
		  };



		firebase.initializeApp(firebaseConfig);
		//firebase.auth().signInWithEmailAndPassword("jasonofthepacific@gmail.com", "password");
		firebase.auth().signInAnonymously();


		chrome.tabs.query({ currentWindow: true, active: true }, function (tabs) {
		  console.log("queryAW" + tabs[0].id);
		});

		chrome.tabs.onActiveChanged.addListener(function(tabId, select) {
		    
					chrome.tabs.query({
		    		active: true,
		    		lastFocusedWindow: true
			}, function(tabs) {
		    // and use that tab to fill in out title and url
		    	var tab = tabs[0];
		    	console.log("AChange: " + tab.url);
		    	//alert(tab.url);

		 

			});

		});


		



		chrome.tabs.onCreated.addListener(function(tab) {         
		   console.log(tab)
		});


		chrome.tabs.onUpdated.addListener(function
		  (tabId, changeInfo, tab) {



		    // read changeInfo data and do something with it (like read the url)
		    if (changeInfo.url) {
				console.log("Updated:" + changeInfo.url);
				

				var urlSpec = new URL(changeInfo.url)
				var proto = urlSpec.protocol

				if(proto === 'https:' || proto === 'http:'){
					var hostref = btoa(urlSpec.hostname).replace('/', '_')
					var sitename = btoa(changeInfo.url).replace('/', '_')

				

					addUrlToHistory(hostref,sitename,changeInfo.url);

					

					
					//console.log(urlSpec.protocol)

					//console.log(btoa(changeInfo.url))
				}


				
				
			


		    }
		  }
		);

		console.log('listenering')
		let id = 100;
		chrome.browserAction.onClicked.addListener(() => {
			console.log('on action clicked')
		chrome.tabs.captureVisibleTab((screenshotUrl) => {
		    const viewTabUrl = chrome.extension.getURL('screenshot.html?id=' + id++)
		    let targetId = null;
		chrome.tabs.onUpdated.addListener(function listener(tabId,     changedProps) {
		if (tabId != targetId || changedProps.status != "complete")
		        return;
		chrome.tabs.onUpdated.removeListener(listener);
		const views = chrome.extension.getViews();
		      for (let i = 0; i < views.length; i++) {
		        let view = views[i];
		        if (view.location.href == viewTabUrl) {
		          view.setScreenshotUrl(screenshotUrl);
		          console.log('screenUrl:'+screenshotUrl)
		          break;
		        }
		      }
		    });
		chrome.tabs.create({url: viewTabUrl}, (tab) => {
		      targetId = tab.id;
		    });
		  });


		});