
console.log('hello sandbox');

console.log(document)



var node = document.createElement("img");
node.setAttribute('src','https://c4.wallpaperflare.com/wallpaper/431/928/855/anime-my-teen-romantic-comedy-snafu-iroha-isshiki-yui-yuigahama-yukino-yukinoshita-hd-wallpaper-preview.jpg')    

//node.style.position = 'fixed'
//node.style.left = 0
//node.style.top = 700

             // Create a <li> node
var textnode = document.createTextNode("Random Insert Text");         // Create a text node
//node.appendChild(textnode);                              // Append the text to <li>
//document.body.prepend(node);

chrome.runtime.onMessage.addListener(
  function(request, sender, sendResponse) {
    console.log(sender.tab ?
                "from a content script:" + sender.tab.url :
                "from the extension");
    if (request.greeting == "hello")
      sendResponse({farewell: "goodbye"});
  });